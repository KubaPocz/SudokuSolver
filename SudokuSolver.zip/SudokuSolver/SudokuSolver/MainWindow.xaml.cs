﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SudokuSolver
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int[,] mainSudoku = new int[9, 9];
        public MainWindow()
        {
            InitializeComponent();
            InsertTextBoxes();
        }
        private void InsertTextBoxes()
        {
            for (int row = 1; row < 10; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    TextBox textBox = new TextBox
                    {
                        BorderThickness = new Thickness(0),
                        VerticalAlignment = VerticalAlignment.Stretch,
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        TextAlignment = TextAlignment.Center,
                        VerticalContentAlignment = VerticalAlignment.Center,
                        FontSize = 20
                    };
                    Grid.SetRow(textBox, row);
                    Grid.SetColumn(textBox, col);
                    sudoku.Children.Add(textBox);
                }
            }
            for (int i = 1; i < 9; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Line line1 = new Line
                    {
                        Y2 = 50,
                        Stroke = new SolidColorBrush(Colors.Black),
                        StrokeThickness = 1,
                    };
                    if (i % 3 == 0)
                    {
                        line1.StrokeThickness = 4;
                    }
                    Grid.SetColumn(line1, i);
                    Grid.SetRow(line1, j);
                    sudoku.Children.Add(line1);

                    Line line2 = new Line
                    {
                        X2 = 50,
                        Stroke = new SolidColorBrush(Colors.Black),
                        StrokeThickness = 1,
                    };
                    if (i % 3 == 0)
                    {
                        line2.StrokeThickness = 2;
                    }
                    Grid.SetColumn(line2, j - 1);
                    Grid.SetRow(line2, i + 1);
                    sudoku.Children.Add(line2);
                }
            }
        }

        private void Solver_Button_Click(object sender, RoutedEventArgs e)
        {
            bool isCorrect = true;
            for (int row = 1; row < 10; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    foreach (UIElement uie in sudoku.Children)
                    {
                        if (Grid.GetRow(uie) == row && Grid.GetColumn(uie) == col)
                        {
                            if (uie is TextBox textBox)
                            {
                                if (textBox.Text != "" && !(int.TryParse(textBox.Text, out int i) && i > 0 && i < 10))
                                {
                                    textBox.Background = new SolidColorBrush(Colors.IndianRed);
                                    isCorrect = false;
                                }
                                else
                                {
                                    if (textBox.Text == "")
                                    {
                                        mainSudoku[row - 1, col] = 0;
                                        textBox.Background = new SolidColorBrush(Colors.PaleGreen);
                                    }
                                    else if (int.TryParse(textBox.Text, out int value) && value > 0 && value < 10)
                                    {
                                        mainSudoku[row - 1, col] = value;
                                        textBox.Background = new SolidColorBrush(Colors.LightGray);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (isCorrect)
            {
                if (SolveSudoku(mainSudoku, 0, 0))
                {
                    PrintStudoku(mainSudoku);
                }
                else
                {
                    MessageBox.Show("Brak rozwiązania podanego sudoku", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Błędne dane!", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private bool SolveSudoku(int[,] board, int row, int col)
        {
            if (row == 9)
                return true;

            if (col == 9)
                return SolveSudoku(board, row + 1, 0);

            if (board[row, col] != 0)
                return SolveSudoku(board, row, col + 1);

            for (int num = 1; num <= 9; num++)
            {
                if (IsValid(board, row, col, num))
                {
                    board[row, col] = num;

                    if (SolveSudoku(board, row, col + 1))
                        return true;

                    board[row, col] = 0;
                }
            }

            return false;
        }

        private bool IsValid(int[,] board, int row, int col, int num)
        {
            for (int x = 0; x < 9; x++)
                if (board[row, x] == num || board[x, col] == num)
                    return false;

            int startRow = (row / 3) * 3;
            int startCol = (col / 3) * 3;

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (board[startRow + i, startCol + j] == num)
                        return false;

            return true;
        }

        private void PrintStudoku(int[,] board)
        {
            for (int row = 1; row < 10; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    foreach (UIElement uie in sudoku.Children)
                    {
                        if (Grid.GetRow(uie) == row && Grid.GetColumn(uie) == col)
                        {
                            if (uie is TextBox textBox)
                            {
                                textBox.Text = Convert.ToString(mainSudoku[row - 1, col]);
                            }
                        }
                    }
                }
            }
        }
        private void TimerEnd()
        {
            MessageBox.Show("Za długi czas działania programu, sprawdź wprowadzone dane", "Upłynął czas", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Reset_Button_Click(object sender, RoutedEventArgs e)
        {
            for (int row = 1; row < 10; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    foreach (UIElement uie in sudoku.Children)
                    {
                        if (Grid.GetRow(uie) == row && Grid.GetColumn(uie) == col)
                        {
                            if (uie is TextBox textBox)
                            {
                                textBox.Text = "";
                                textBox.Background = new SolidColorBrush(Colors.White);
                            }
                        }
                    }
                }
            }
        }
    }
}